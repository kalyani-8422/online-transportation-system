
import { useState, useEffect } from "react";
import HeroSection from "../components/HeroSection";
import SearchForm from "../components/SearchForm";
import RouteCard from "../components/RouteCard";
import FeatureSection from "../components/FeatureSection";
import { toast } from "sonner";

// Mock data for routes
const mockRoutes = [
  {
    id: 1,
    name: "Morning Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "07:30 AM",
    arrivalTime: "08:15 AM",
    price: 45.00
  },
  {
    id: 2,
    name: "Afternoon Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "01:00 PM",
    arrivalTime: "01:45 PM",
    price: 45.00
  },
  {
    id: 3,
    name: "Evening Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Vijayawada",
    departureTime: "05:30 PM",
    arrivalTime: "06:45 PM",
    price: 85.00
  },
  {
    id: 4,
    name: "Weekend Special",
    departure: "Vijayawada",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "09:00 AM",
    arrivalTime: "10:15 AM",
    price: 85.00
  }
];

const Index = () => {
  const [popularRoutes, setPopularRoutes] = useState(mockRoutes);

  useEffect(() => {
    // In a real application, we would fetch routes from an API
    // For now, we're using mock data
    toast.success("Welcome to Vignan Transport System!", {
      description: "Book your journey with ease.",
    });
    
    // This would typically be an API call
    // e.g. fetch('/api/routes/popular').then(res => res.json()).then(data => setPopularRoutes(data));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <HeroSection />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="mb-16">
          <SearchForm />
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Popular Routes</h2>
          <p className="mt-2 text-gray-600">
            Select from frequently traveled routes between Vignan campuses and nearby cities
          </p>
        </div>
        
        <div className="grid grid-cols-1 gap-6 md:gap-8">
          {popularRoutes.map((route) => (
            <RouteCard
              key={route.id}
              id={route.id}
              name={route.name}
              departure={route.departure}
              arrival={route.arrival}
              departureTime={route.departureTime}
              arrivalTime={route.arrivalTime}
              price={route.price}
            />
          ))}
        </div>
      </div>
      
      <FeatureSection />
    </div>
  );
};

export default Index;
