
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

// Mock data for schedules
const initialSchedules = [
  {
    id: 1,
    name: "Morning Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "07:30 AM",
    arrivalTime: "08:15 AM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 45.00,
    busType: "AC"
  },
  {
    id: 2,
    name: "Afternoon Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "01:00 PM",
    arrivalTime: "01:45 PM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 45.00,
    busType: "AC"
  },
  {
    id: 3,
    name: "Evening Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Vijayawada",
    departureTime: "05:30 PM",
    arrivalTime: "06:45 PM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 85.00,
    busType: "AC Sleeper"
  },
  {
    id: 4,
    name: "Weekend Special",
    departure: "Vijayawada",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "09:00 AM",
    arrivalTime: "10:15 AM",
    days: ["Saturday", "Sunday"],
    price: 85.00,
    busType: "AC"
  },
  {
    id: 5,
    name: "Tenali Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Tenali",
    departureTime: "04:30 PM",
    arrivalTime: "05:30 PM",
    days: ["Monday", "Wednesday", "Friday"],
    price: 60.00,
    busType: "Non-AC"
  },
  {
    id: 6,
    name: "Bapatla Connect",
    departure: "Bapatla",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "07:00 AM",
    arrivalTime: "08:15 AM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 70.00,
    busType: "Non-AC"
  },
  {
    id: 7,
    name: "Night Service",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "08:30 PM",
    arrivalTime: "09:15 PM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 50.00,
    busType: "AC"
  },
  {
    id: 8,
    name: "Early Bird",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "06:00 AM",
    arrivalTime: "06:45 AM",
    days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    price: 45.00,
    busType: "Non-AC"
  }
];

type Schedule = {
  id: number;
  name: string;
  departure: string;
  arrival: string;
  departureTime: string;
  arrivalTime: string;
  days: string[];
  price: number;
  busType: string;
};

type FilterOptions = {
  departure: string;
  arrival: string;
  day: string;
  busType: string;
};

const Schedules = () => {
  const [schedules, setSchedules] = useState<Schedule[]>(initialSchedules);
  const [filters, setFilters] = useState<FilterOptions>({
    departure: "",
    arrival: "",
    day: "",
    busType: ""
  });

  // Get unique values for filter dropdowns
  const departures = Array.from(new Set(initialSchedules.map(s => s.departure)));
  const arrivals = Array.from(new Set(initialSchedules.map(s => s.arrival)));
  const busTypes = Array.from(new Set(initialSchedules.map(s => s.busType)));
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  useEffect(() => {
    // Apply filters
    let filteredSchedules = [...initialSchedules];
    
    if (filters.departure) {
      filteredSchedules = filteredSchedules.filter(s => s.departure === filters.departure);
    }
    
    if (filters.arrival) {
      filteredSchedules = filteredSchedules.filter(s => s.arrival === filters.arrival);
    }
    
    if (filters.day) {
      filteredSchedules = filteredSchedules.filter(s => s.days.includes(filters.day));
    }
    
    if (filters.busType) {
      filteredSchedules = filteredSchedules.filter(s => s.busType === filters.busType);
    }
    
    setSchedules(filteredSchedules);
  }, [filters]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      departure: "",
      arrival: "",
      day: "",
      busType: ""
    });
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Bus Schedules
          </h1>
          <p className="mt-4 text-xl text-gray-500">
            View all available bus routes and timings
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Filter Schedules</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label htmlFor="departure" className="block text-sm font-medium text-gray-700 mb-1">From</label>
              <select
                id="departure"
                name="departure"
                value={filters.departure}
                onChange={handleFilterChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
              >
                <option value="">All Departures</option>
                {departures.map((dep, index) => (
                  <option key={index} value={dep}>{dep}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="arrival" className="block text-sm font-medium text-gray-700 mb-1">To</label>
              <select
                id="arrival"
                name="arrival"
                value={filters.arrival}
                onChange={handleFilterChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
              >
                <option value="">All Arrivals</option>
                {arrivals.map((arr, index) => (
                  <option key={index} value={arr}>{arr}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="day" className="block text-sm font-medium text-gray-700 mb-1">Day</label>
              <select
                id="day"
                name="day"
                value={filters.day}
                onChange={handleFilterChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
              >
                <option value="">All Days</option>
                {days.map((day, index) => (
                  <option key={index} value={day}>{day}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="busType" className="block text-sm font-medium text-gray-700 mb-1">Bus Type</label>
              <select
                id="busType"
                name="busType"
                value={filters.busType}
                onChange={handleFilterChange}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
              >
                <option value="">All Types</option>
                {busTypes.map((type, index) => (
                  <option key={index} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button
              onClick={clearFilters}
              className="px-4 py-2 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              Clear Filters
            </button>
          </div>
        </div>

        {/* Schedules Table */}
        <div className="bg-white shadow overflow-hidden rounded-lg">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Route Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">To</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Departure</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Arrival</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Days</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bus Type</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {schedules.length > 0 ? (
                  schedules.map((schedule) => (
                    <tr key={schedule.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{schedule.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.departure}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.arrival}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.departureTime}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{schedule.arrivalTime}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {schedule.days.join(', ')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          schedule.busType.includes('AC') ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {schedule.busType}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">₹{schedule.price.toFixed(2)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Link
                          to={`/seats/${schedule.id}`}
                          className="text-indigo-600 hover:text-indigo-900"
                        >
                          Book Now
                        </Link>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-4 text-center text-sm text-gray-500">
                      No schedules found matching your filters. Please try different filter options.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Schedules;
