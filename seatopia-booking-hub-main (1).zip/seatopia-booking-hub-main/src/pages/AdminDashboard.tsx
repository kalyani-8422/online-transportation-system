import React, { useState, useEffect } from 'react';
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";
import { CalendarIcon, UsersIcon, MapIcon, BarChart3Icon } from "lucide-react";
import AnalyticsPanel from "@/components/AnalyticsPanel";
import { useAnalytics } from '@/hooks/useAnalytics';

// Mock data for dashboard
const routeData = [
  { id: 1, name: 'Morning Express', activeBookings: 45, totalCapacity: 50 },
  { id: 2, name: 'Afternoon Shuttle', activeBookings: 32, totalCapacity: 50 },
  { id: 3, name: 'Evening Express', activeBookings: 28, totalCapacity: 50 },
  { id: 4, name: 'Weekend Special', activeBookings: 18, totalCapacity: 30 },
];

const userBreakdown = {
  students: 320,
  faculty: 45,
  admin: 8,
  total: 373
};

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();
  const analytics = useAnalytics();
  
  // Simulate fetching data from backend
  useEffect(() => {
    // Check if user is logged in as admin
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const userRole = localStorage.getItem('userRole');
    
    if (isLoggedIn !== 'true' || userRole !== 'admin') {
      toast({
        title: "Access Denied",
        description: "You don't have permission to view this page",
        variant: "destructive"
      });
      navigate('/');
      return;
    }
    
    // Track page view
    analytics.trackEvent('admin_dashboard_view', {
      tab: activeTab
    });
    
    // Simulate API call delay
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [navigate, toast, activeTab, analytics]);
  
  // Track tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    analytics.trackEvent('admin_tab_changed', {
      tabName: value
    });
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading dashboard...</div>;
  }

  return (
    <div className="bg-white min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
        
        <Tabs defaultValue="overview" className="space-y-4" onValueChange={handleTabChange}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="routes">Routes</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">123</div>
                  <p className="text-xs text-muted-foreground">+5% from last week</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Routes</CardTitle>
                  <MapIcon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">8</div>
                  <p className="text-xs text-muted-foreground">+2 since last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <UsersIcon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{userBreakdown.total}</div>
                  <p className="text-xs text-muted-foreground">{userBreakdown.students} students, {userBreakdown.faculty} faculty</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fill Rate</CardTitle>
                  <BarChart3Icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">68%</div>
                  <p className="text-xs text-muted-foreground">+12% from last month</p>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Route Utilization</CardTitle>
                <CardDescription>Active vs. total capacity for each route</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-none space-y-2">
                  {routeData.map(route => (
                    <li key={route.id} className="flex items-center justify-between">
                      <span>{route.name}</span>
                      <span>{route.activeBookings} / {route.totalCapacity}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="routes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {routeData.map(route => (
                <Card key={route.id}>
                  <CardHeader>
                    <CardTitle>{route.name}</CardTitle>
                    <CardDescription>Route ID: {route.id}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p>Active Bookings: {route.activeBookings}</p>
                    <p>Total Capacity: {route.totalCapacity}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Statistics</CardTitle>
                <CardDescription>Breakdown of user roles</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Total Students: {userBreakdown.students}</p>
                <p>Total Faculty: {userBreakdown.faculty}</p>
                <p>Total Admins: {userBreakdown.admin}</p>
                <p>Total Users: {userBreakdown.total}</p>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-4">
            <AnalyticsPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
