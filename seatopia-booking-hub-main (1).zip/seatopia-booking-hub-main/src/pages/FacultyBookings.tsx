import React, { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";
import { useAnalytics } from '@/hooks/useAnalytics';
import { Button } from "@/components/ui/button";

const FacultyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const analytics = useAnalytics();
  
  useEffect(() => {
    // Check if user is logged in as faculty or admin
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const userRole = localStorage.getItem('userRole');
    
    if (isLoggedIn !== 'true' || (userRole !== 'faculty' && userRole !== 'admin')) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to view this page",
        variant: "destructive"
      });
      navigate('/');
      return;
    }
    
    // Check initial GPS tracking status
    setLocationEnabled(analytics.isGpsTrackingEnabled());
    
    // Track page view with additional context
    analytics.trackEvent('faculty_bookings_page_view', {
      userType: userRole
    });
    
    // Mock data for faculty-managed bookings
    const bookingsData = [
      { id: 1, routeName: 'Morning Express', departure: 'Main Campus', arrival: 'Guntur', studentName: 'Ajay Kumar', studentId: 'CSE001', seatNumber: 5, journeyDate: '2023-05-15', status: 'Confirmed' },
      { id: 2, routeName: 'Afternoon Shuttle', departure: 'Main Campus', arrival: 'Vijayawada', studentName: 'Priya Sharma', studentId: 'ECE015', seatNumber: 12, journeyDate: '2023-05-16', status: 'Pending' },
      { id: 3, routeName: 'Evening Campus Bus', departure: 'Guntur', arrival: 'Main Campus', studentName: 'Ravi Verma', studentId: 'ME023', seatNumber: 8, journeyDate: '2023-05-15', status: 'Confirmed' },
      { id: 4, routeName: 'Morning Express', departure: 'Main Campus', arrival: 'Guntur', studentName: 'Sneha Reddy', studentId: 'CSE045', seatNumber: 15, journeyDate: '2023-05-17', status: 'Pending' },
    ];
    
    setBookings(bookingsData);
    setLoading(false);
  }, [navigate, toast, analytics]);
  
  const handleLocationToggle = () => {
    if (locationEnabled) {
      analytics.disableGpsTracking();
      setLocationEnabled(false);
      toast({
        title: "Location Tracking Disabled",
        description: "GPS tracking has been turned off"
      });
    } else {
      const success = analytics.enableGpsTracking();
      if (success) {
        setLocationEnabled(true);
        toast({
          title: "Location Tracking Enabled",
          description: "GPS tracking has been turned on for better campus navigation"
        });
      } else {
        toast({
          title: "Location Error",
          description: "Could not enable GPS tracking. Please check your browser permissions.",
          variant: "destructive"
        });
      }
    }
    
    // Track this action
    analytics.trackEvent('gps_tracking_toggled', {
      enabled: !locationEnabled
    });
  };
  
  const handleStatusChange = (id, newStatus) => {
    setBookings(bookings.map(booking => 
      booking.id === id ? {...booking, status: newStatus} : booking
    ));
    
    // Track booking status change
    analytics.trackEvent('booking_status_changed', {
      bookingId: id,
      newStatus: newStatus
    });
    
    toast({
      title: "Status Updated",
      description: `Booking #${id} status changed to ${newStatus}`,
    });
  };
  
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading bookings...</div>;
  }

  return (
    <div className="bg-white min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Manage Student Bookings</h1>
          
          <Button 
            variant={locationEnabled ? "default" : "outline"}
            onClick={handleLocationToggle}
            className={`${locationEnabled ? 'bg-green-600 hover:bg-green-700' : 'border-green-600 text-green-600'}`}
          >
            {locationEnabled ? 'Disable Location' : 'Enable Location'}
          </Button>
        </div>
        
        <div>
          <Table>
            <TableCaption>Student transport bookings</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Locations</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>ID</TableHead>
                <TableHead>Seat</TableHead>
                <TableHead>Journey Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bookings.map((booking) => (
                <TableRow key={booking.id}>
                  <TableCell>{booking.id}</TableCell>
                  <TableCell>{booking.routeName}</TableCell>
                  <TableCell>{booking.departure} to {booking.arrival}</TableCell>
                  <TableCell>{booking.studentName}</TableCell>
                  <TableCell>{booking.studentId}</TableCell>
                  <TableCell>{booking.seatNumber}</TableCell>
                  <TableCell>{booking.journeyDate}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${
                      booking.status === 'Confirmed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {booking.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    {booking.status === 'Pending' ? (
                      <button 
                        onClick={() => handleStatusChange(booking.id, 'Confirmed')}
                        className="text-sm bg-indigo-600 text-white px-2 py-1 rounded hover:bg-indigo-700"
                      >
                        Confirm
                      </button>
                    ) : (
                      <button 
                        onClick={() => handleStatusChange(booking.id, 'Cancelled')}
                        className="text-sm bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                      >
                        Cancel
                      </button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default FacultyBookings;
