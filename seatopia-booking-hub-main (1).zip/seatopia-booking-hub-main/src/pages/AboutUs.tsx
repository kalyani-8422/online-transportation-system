
import React from 'react';

const AboutUs = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            About Vignan Transport System
          </h1>
          <p className="mt-4 text-xl text-gray-500">
            Providing safe and reliable transportation for students and faculty
          </p>
        </div>

        <div className="prose prose-indigo prose-lg text-gray-500 mx-auto mb-12">
          <p>
            Vignan Transport System is dedicated to providing reliable, comfortable, and safe transportation services for students, faculty, and staff of Vignan University. With a fleet of modern buses equipped with the latest amenities, we ensure that your journey between campuses and nearby cities is pleasant and hassle-free.
          </p>
          
          <h2>Our Mission</h2>
          <p>
            To provide efficient, reliable, and sustainable transportation solutions for the Vignan University community, enhancing accessibility to education and connecting our campuses.
          </p>
          
          <h2>Our Fleet</h2>
          <p>
            Our fleet consists of over 50 modern buses that are regularly maintained to ensure safety and comfort. All our buses are equipped with:
          </p>
          <ul>
            <li>Air conditioning</li>
            <li>Comfortable seating</li>
            <li>Wi-Fi connectivity</li>
            <li>GPS tracking for real-time location updates</li>
            <li>First aid kits and emergency equipment</li>
          </ul>
          
          <h2>Our Coverage</h2>
          <p>
            We operate routes connecting Vignan University's main campus in Vadlamudi with other campuses and major cities including:
          </p>
          <ul>
            <li>Guntur</li>
            <li>Vijayawada</li>
            <li>Tenali</li>
            <li>Bapatla</li>
            <li>And more locations based on student and faculty needs</li>
          </ul>
          
          <h2>Commitment to Safety</h2>
          <p>
            Safety is our top priority. All our drivers are professionally trained and have years of experience. Our vehicles undergo regular maintenance checks and are equipped with safety features to ensure a secure journey for all passengers.
          </p>
        </div>
        
        <div className="bg-indigo-50 rounded-lg p-8 mb-12">
          <h2 className="text-2xl font-bold text-indigo-800 mb-4">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-indigo-600 text-xl font-bold mb-2">Reliability</div>
              <p className="text-gray-600">We ensure our services run on schedule, respecting your time and commitments.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-indigo-600 text-xl font-bold mb-2">Safety</div>
              <p className="text-gray-600">We prioritize the safety of our passengers with well-maintained vehicles and trained drivers.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-indigo-600 text-xl font-bold mb-2">Sustainability</div>
              <p className="text-gray-600">We're committed to reducing our environmental impact through efficient route planning.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
