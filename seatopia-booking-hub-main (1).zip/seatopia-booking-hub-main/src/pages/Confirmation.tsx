
import { useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { toast } from "sonner";

const Confirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const booking = location.state?.booking;

  useEffect(() => {
    if (!booking) {
      toast.error("Invalid booking information");
      navigate("/");
      return;
    }
    
    // Show success message
    toast.success("Booking Confirmed!", {
      description: `Your seat has been successfully booked.`,
    });
  }, [booking, navigate]);

  if (!booking) {
    return null; // We'll redirect in the useEffect
  }

  const handlePrintTicket = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <svg className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Booking Confirmed!</h1>
          <p className="text-gray-600 mt-2">Your transportation has been successfully booked</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8 print:shadow-none">
          <div className="bg-indigo-600 px-6 py-4">
            <h2 className="text-xl font-bold text-white">E-Ticket</h2>
            <div className="text-indigo-100 font-medium">{booking.routeName}</div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Passenger</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.customerName}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Email</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.customerEmail}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Booking ID</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">#{booking.bookingId}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Date</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.date}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">From</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.departureLocation}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">To</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.arrivalLocation}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Departure Time</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.departureTime}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Arrival Time</h3>
                  <p className="mt-1 text-lg font-medium text-gray-900">{booking.arrivalTime}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Seat Number</h3>
                <div className="mt-1 inline-flex items-center justify-center px-4 py-2 bg-indigo-100 text-indigo-800 text-lg font-bold rounded-md">
                  {booking.seatNumber}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Price</h3>
                <p className="mt-1 text-xl font-bold text-indigo-600">₹{booking.price.toFixed(2)}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 px-6 py-4 print:hidden">
            <p className="text-sm text-gray-600">
              Please show this ticket when boarding. Thank you for choosing Vignan Transport System!
            </p>
          </div>
        </div>
        
        <div className="flex justify-between print:hidden">
          <Link
            to="/"
            className="px-6 py-3 bg-gray-200 text-gray-800 font-medium rounded-md hover:bg-gray-300 transition-colors"
          >
            Return to Home
          </Link>
          <button
            onClick={handlePrintTicket}
            className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 transition-colors"
          >
            Print Ticket
          </button>
        </div>
      </div>
    </div>
  );
};

export default Confirmation;
