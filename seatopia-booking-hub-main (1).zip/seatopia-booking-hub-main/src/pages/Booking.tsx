
import { useState, useEffect } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";
import BookingForm from "../components/BookingForm";
import { toast } from "sonner";

// Mock data for routes
const mockRoutes = [
  {
    id: 1,
    name: "Morning Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "07:30 AM",
    arrivalTime: "08:15 AM",
    price: 45.00,
    totalSeats: 40,
    bookedSeats: [3, 7, 12, 18, 25, 32, 38]
  },
  {
    id: 2,
    name: "Afternoon Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "01:00 PM",
    arrivalTime: "01:45 PM",
    price: 45.00,
    totalSeats: 40,
    bookedSeats: [4, 9, 14, 22, 27, 33]
  },
  {
    id: 3,
    name: "Evening Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Vijayawada",
    departureTime: "05:30 PM",
    arrivalTime: "06:45 PM",
    price: 85.00,
    totalSeats: 40,
    bookedSeats: [1, 5, 10, 15, 19, 28, 35, 36]
  },
  {
    id: 4,
    name: "Weekend Special",
    departure: "Vijayawada",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "09:00 AM",
    arrivalTime: "10:15 AM",
    price: 85.00,
    totalSeats: 40,
    bookedSeats: [2, 6, 11, 20, 24, 30, 37, 39]
  },
  {
    id: 5,
    name: "Late Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "08:00 PM",
    arrivalTime: "08:45 PM",
    price: 50.00,
    totalSeats: 40,
    bookedSeats: [8, 13, 21, 29, 31, 34, 40]
  }
];

const Booking = () => {
  const { routeId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [route, setRoute] = useState(null);
  const [seatNumber, setSeatNumber] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if we received route and seat from the location state
    if (location.state?.route && location.state?.seatNumber) {
      setRoute(location.state.route);
      setSeatNumber(location.state.seatNumber);
      setLoading(false);
    } else {
      // Fallback to API call if no state is passed
      setTimeout(() => {
        const foundRoute = mockRoutes.find(r => r.id === parseInt(routeId));
        if (foundRoute) {
          setRoute(foundRoute);
          // No seat information, redirect to seat selection
          toast.error("Please select a seat first");
          navigate(`/seats/${routeId}`);
        } else {
          toast.error("Route not found");
          navigate("/");
        }
        setLoading(false);
      }, 500);
    }
  }, [routeId, location.state, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
          <p className="mt-4 text-gray-600">Loading booking details...</p>
        </div>
      </div>
    );
  }

  if (!route || !seatNumber) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Invalid booking details</p>
          <button
            onClick={() => navigate("/")}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            Go Back Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Complete Your Booking</h1>
          <p className="text-gray-600 mt-2">Enter your details to confirm your reservation</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="flex flex-col justify-center">
            <div className="p-6 bg-indigo-50 rounded-lg">
              <h2 className="text-lg font-semibold text-indigo-800 mb-4">Booking Details</h2>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <svg className="h-5 w-5 text-indigo-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>Make sure your personal details are correct</span>
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 text-indigo-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>We'll send the booking confirmation to your email</span>
                </li>
                <li className="flex items-center">
                  <svg className="h-5 w-5 text-indigo-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>Your seat will be reserved for 10 minutes</span>
                </li>
              </ul>
            </div>
          </div>
          
          <BookingForm
            routeId={route.id}
            seatNumber={seatNumber}
            routeName={route.name}
            departureLocation={route.departure}
            arrivalLocation={route.arrival}
            departureTime={route.departureTime}
            arrivalTime={route.arrivalTime}
            price={route.price}
          />
        </div>
      </div>
    </div>
  );
};

export default Booking;
