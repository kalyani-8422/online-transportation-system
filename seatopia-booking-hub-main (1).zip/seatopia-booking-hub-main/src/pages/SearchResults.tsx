
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import RouteCard from "../components/RouteCard";

// Mock data for search results
const mockAllRoutes = [
  {
    id: 1,
    name: "Morning Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "07:30 AM",
    arrivalTime: "08:15 AM",
    price: 45.00
  },
  {
    id: 2,
    name: "Mid-Morning Shuttle",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "10:30 AM",
    arrivalTime: "11:15 AM",
    price: 45.00
  },
  {
    id: 3,
    name: "Afternoon Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "01:00 PM",
    arrivalTime: "01:45 PM",
    price: 45.00
  },
  {
    id: 4,
    name: "Evening Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Vijayawada",
    departureTime: "05:30 PM",
    arrivalTime: "06:45 PM",
    price: 85.00
  },
  {
    id: 5,
    name: "Late Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "08:00 PM",
    arrivalTime: "08:45 PM",
    price: 50.00
  }
];

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);

  const fromLocation = searchParams.get("from");
  const toLocation = searchParams.get("to");
  const journeyDate = searchParams.get("date");

  useEffect(() => {
    // Simulate API call to get search results
    setLoading(true);
    setTimeout(() => {
      // Filter routes based on search params
      const filteredRoutes = mockAllRoutes.filter(
        route => 
          route.departure === fromLocation && 
          route.arrival === toLocation
      );
      setRoutes(filteredRoutes);
      setLoading(false);
    }, 500);
    
    // In a real application, this would be an API call
    // e.g. fetch(`/api/routes?from=${fromLocation}&to=${toLocation}&date=${journeyDate}`)
    //      .then(res => res.json())
    //      .then(data => setRoutes(data))
    //      .finally(() => setLoading(false));
  }, [fromLocation, toLocation, journeyDate]);
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow-sm rounded-lg p-6 mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Search Results</h1>
          <p className="text-gray-600 mt-2">
            {fromLocation} to {toLocation} on {journeyDate}
          </p>
          
          <div className="mt-4 flex flex-wrap gap-4">
            <div className="bg-indigo-50 px-3 py-1 rounded-full text-indigo-700 text-sm font-medium">
              Date: {journeyDate}
            </div>
            <div className="bg-indigo-50 px-3 py-1 rounded-full text-indigo-700 text-sm font-medium">
              From: {fromLocation}
            </div>
            <div className="bg-indigo-50 px-3 py-1 rounded-full text-indigo-700 text-sm font-medium">
              To: {toLocation}
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
            <p className="mt-4 text-gray-600">Looking for available routes...</p>
          </div>
        ) : routes.length > 0 ? (
          <div className="grid grid-cols-1 gap-6">
            {routes.map((route) => (
              <RouteCard
                key={route.id}
                id={route.id}
                name={route.name}
                departure={route.departure}
                arrival={route.arrival}
                departureTime={route.departureTime}
                arrivalTime={route.arrivalTime}
                price={route.price}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <svg
              className="mx-auto h-12 w-12 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">No routes found</h3>
            <p className="mt-1 text-gray-500">
              We couldn't find any routes matching your search criteria. Please try different locations or dates.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;
