
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import SeatGrid from "../components/SeatGrid";
import { toast } from "sonner";

// Mock data for routes and booked seats
const mockRoutes = [
  {
    id: 1,
    name: "Morning Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Guntur City",
    departureTime: "07:30 AM",
    arrivalTime: "08:15 AM",
    price: 45.00,
    totalSeats: 40,
    bookedSeats: [3, 7, 12, 18, 25, 32, 38]
  },
  {
    id: 2,
    name: "Afternoon Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "01:00 PM",
    arrivalTime: "01:45 PM",
    price: 45.00,
    totalSeats: 40,
    bookedSeats: [4, 9, 14, 22, 27, 33]
  },
  {
    id: 3,
    name: "Evening Express",
    departure: "Main Campus (Vadlamudi)",
    arrival: "Vijayawada",
    departureTime: "05:30 PM",
    arrivalTime: "06:45 PM",
    price: 85.00,
    totalSeats: 40,
    bookedSeats: [1, 5, 10, 15, 19, 28, 35, 36]
  },
  {
    id: 4,
    name: "Weekend Special",
    departure: "Vijayawada",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "09:00 AM",
    arrivalTime: "10:15 AM",
    price: 85.00,
    totalSeats: 40,
    bookedSeats: [2, 6, 11, 20, 24, 30, 37, 39]
  },
  {
    id: 5,
    name: "Late Shuttle",
    departure: "Guntur City",
    arrival: "Main Campus (Vadlamudi)",
    departureTime: "08:00 PM",
    arrivalTime: "08:45 PM",
    price: 50.00,
    totalSeats: 40,
    bookedSeats: [8, 13, 21, 29, 31, 34, 40]
  }
];

const SeatSelection = () => {
  const { routeId } = useParams();
  const navigate = useNavigate();
  const [route, setRoute] = useState(null);
  const [selectedSeat, setSelectedSeat] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to get route details
    setLoading(true);
    setTimeout(() => {
      const foundRoute = mockRoutes.find(r => r.id === parseInt(routeId));
      if (foundRoute) {
        setRoute(foundRoute);
      } else {
        toast.error("Route not found");
        navigate("/");
      }
      setLoading(false);
    }, 500);
    
    // In a real application, this would be an API call
    // e.g. fetch(`/api/routes/${routeId}`).then(res => res.json()).then(data => setRoute(data))
  }, [routeId, navigate]);

  const handleSeatSelect = (seatNumber) => {
    setSelectedSeat(seatNumber);
  };

  const handleContinue = () => {
    if (!selectedSeat) {
      toast.error("Please select a seat to continue");
      return;
    }
    
    // Navigate to booking page with route and seat info
    navigate(`/booking/${routeId}`, { 
      state: { 
        route,
        seatNumber: selectedSeat 
      } 
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
          <p className="mt-4 text-gray-600">Loading route details...</p>
        </div>
      </div>
    );
  }

  if (!route) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Route not found</p>
          <button
            onClick={() => navigate("/")}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            Go Back Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow-sm rounded-lg p-6 mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Select Your Seat</h1>
          <p className="text-gray-600 mt-2">
            {route.name} - {route.departure} to {route.arrival}
          </p>
          
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="text-sm">
              <span className="text-gray-500">Departure:</span>
              <span className="font-medium ml-2">{route.departureTime}</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-500">Arrival:</span>
              <span className="font-medium ml-2">{route.arrivalTime}</span>
            </div>
          </div>
        </div>
        
        <SeatGrid
          totalSeats={route.totalSeats}
          bookedSeats={route.bookedSeats}
          onSeatSelect={handleSeatSelect}
        />
        
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleContinue}
            disabled={!selectedSeat}
            className={`px-6 py-3 rounded-md font-medium text-white ${
              selectedSeat
                ? "bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                : "bg-gray-400 cursor-not-allowed"
            }`}
          >
            {selectedSeat ? `Continue with Seat ${selectedSeat}` : "Select a Seat to Continue"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SeatSelection;
