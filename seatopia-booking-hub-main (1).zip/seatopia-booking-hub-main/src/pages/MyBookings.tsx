
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/components/ui/use-toast";
import { useAnalytics } from '@/hooks/useAnalytics';

// Mock data for user bookings
const mockBookings = [
  { 
    id: 101, 
    routeName: 'Morning Express', 
    departure: 'Main Campus', 
    arrival: 'Guntur', 
    journeyDate: '2023-05-20', 
    departureTime: '07:30 AM', 
    arrivalTime: '08:15 AM',
    seatNumber: 15, 
    status: 'Confirmed',
    bookingDate: '2023-05-10'
  },
  { 
    id: 102, 
    routeName: 'Evening Campus Bus', 
    departure: 'Vijayawada', 
    arrival: 'Main Campus', 
    journeyDate: '2023-05-22', 
    departureTime: '05:30 PM', 
    arrivalTime: '06:15 PM',
    seatNumber: 8, 
    status: 'Confirmed',
    bookingDate: '2023-05-12'
  },
  { 
    id: 103, 
    routeName: 'Weekend Special', 
    departure: 'Main Campus', 
    arrival: 'Vijayawada', 
    journeyDate: '2023-05-25', 
    departureTime: '09:00 AM', 
    arrivalTime: '10:15 AM',
    seatNumber: 22, 
    status: 'Pending',
    bookingDate: '2023-05-15'
  },
];

const MyBookings = () => {
  const [bookings, setBookings] = useState(mockBookings);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();
  const analytics = useAnalytics();
  
  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const userRole = localStorage.getItem('userRole');
    const userDepartment = localStorage.getItem('department') || 'Unknown';
    
    if (isLoggedIn !== 'true') {
      toast({
        title: "Access Denied",
        description: "Please log in to view your bookings",
        variant: "destructive"
      });
      navigate('/');
      return;
    }
    
    // Track page view with user context and campus information
    analytics.trackEvent('my_bookings_page_view', {
      userRole,
      department: userDepartment,
      totalBookings: mockBookings.length,
      activeBookings: mockBookings.filter(b => b.status !== 'Cancelled').length
    });
    
    // In a real app, we would fetch bookings from an API
    // Simulating API call with a timeout
    const timer = setTimeout(() => {
      setLoading(false);
      
      // Track when data is loaded
      analytics.trackEvent('bookings_data_loaded', {
        loadTime: 800,
        bookingsCount: mockBookings.length
      });
    }, 800);
    
    return () => clearTimeout(timer);
  }, [navigate, toast, analytics]);
  
  const handleCancelBooking = (id) => {
    // Find the booking to be cancelled
    const bookingToCancel = bookings.find(booking => booking.id === id);
    
    // In a real app, we would call an API to cancel the booking
    setBookings(bookings.map(booking => 
      booking.id === id ? {...booking, status: 'Cancelled'} : booking
    ));
    
    // Track booking cancellation with detailed information
    analytics.trackEvent('booking_cancelled', {
      bookingId: id,
      routeName: bookingToCancel?.routeName,
      journeyDate: bookingToCancel?.journeyDate,
      timeToDeparture: bookingToCancel ? getDaysDifference(new Date(), new Date(bookingToCancel.journeyDate)) : 'unknown',
      cancellationReason: 'User initiated' // In a real app, you might collect this information
    });
    
    toast({
      title: "Booking Cancelled",
      description: `Your booking #${id} has been cancelled successfully.`,
    });
  };
  
  // Helper function to calculate days difference for analytics
  const getDaysDifference = (date1, date2) => {
    const diffTime = Math.abs(date2 - date1);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading your bookings...</div>;
  }

  return (
    <div className="bg-white min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">My Transport Bookings</h1>
        
        {bookings.length === 0 ? (
          <div className="text-center py-10">
            <p className="text-gray-600 mb-4">You don't have any transport bookings yet.</p>
            <button 
              onClick={() => navigate('/')}
              className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
            >
              Book Transport
            </button>
          </div>
        ) : (
          <Table>
            <TableCaption>Your transport bookings</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Booking ID</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Journey</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Seat</TableHead>
                <TableHead>Journey Date</TableHead>
                <TableHead>Booking Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bookings.map((booking) => (
                <TableRow key={booking.id}>
                  <TableCell>{booking.id}</TableCell>
                  <TableCell>{booking.routeName}</TableCell>
                  <TableCell>{booking.departure} to {booking.arrival}</TableCell>
                  <TableCell>{booking.departureTime} - {booking.arrivalTime}</TableCell>
                  <TableCell>{booking.seatNumber}</TableCell>
                  <TableCell>{booking.journeyDate}</TableCell>
                  <TableCell>{booking.bookingDate}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${
                      booking.status === 'Confirmed' 
                        ? 'bg-green-100 text-green-800' 
                        : booking.status === 'Cancelled'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {booking.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    {booking.status !== 'Cancelled' && new Date(booking.journeyDate) > new Date() && (
                      <button 
                        onClick={() => handleCancelBooking(booking.id)}
                        className="text-sm bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                      >
                        Cancel
                      </button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
};

export default MyBookings;
