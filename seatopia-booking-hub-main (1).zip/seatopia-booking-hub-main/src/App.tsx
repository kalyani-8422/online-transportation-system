
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import SearchResults from "./pages/SearchResults";
import SeatSelection from "./pages/SeatSelection";
import Booking from "./pages/Booking";
import Confirmation from "./pages/Confirmation";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import AboutUs from "./pages/AboutUs";
import Contact from "./pages/Contact";
import Schedules from "./pages/Schedules";
import AdminDashboard from "./pages/AdminDashboard";
import FacultyBookings from "./pages/FacultyBookings";
import MyBookings from "./pages/MyBookings";
import { useAnalytics } from "./hooks/useAnalytics";

const queryClient = new QueryClient();

// Component to track route changes
const RouteTracker = () => {
  const location = useLocation();
  const analytics = useAnalytics();
  
  useEffect(() => {
    // Track page view on route change
    analytics.trackPageView();
  }, [location, analytics]);
  
  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <RouteTracker />
        <Navbar />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/search" element={<SearchResults />} />
          <Route path="/seats/:routeId" element={<SeatSelection />} />
          <Route path="/booking/:routeId" element={<Booking />} />
          <Route path="/confirmation" element={<Confirmation />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/schedules" element={<Schedules />} />
          <Route path="/my-bookings" element={<MyBookings />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/faculty/bookings" element={<FacultyBookings />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
