// Analytics service to track user behavior for Vignan University Vadlamudi
type EventData = Record<string, any>;
type LocationData = {lat: number, lng: number};

interface PageViewData {
  path: string;
  referrer: string;
  title: string;
  location?: LocationData;
  [key: string]: any;
}

interface EventBaseData {
  userId: string;
  sessionId: string;
  userRole: string;
  campus: string;
  timestamp: string;
  location?: LocationData;
  [key: string]: any;
}

class AnalyticsService {
  private initialized: boolean = false;
  private userId: string | null = null;
  private sessionId: string = this.generateId();
  private campus: string = 'Vignan University Vadlamudi';
  private events: Array<{name: string, data: EventData, timestamp: number}> = [];
  private gpsTracking: boolean = false;
  private watchId: number | null = null;
  private lastKnownLocation: LocationData | null = null;

  initialize(config: {campus?: string, enableGps?: boolean} = {}): void {
    if (this.initialized) return;
    
    if (config.campus) {
      this.campus = config.campus;
    }
    
    // Generate or retrieve user ID
    const storedUserId = localStorage.getItem('analytics_user_id');
    if (storedUserId) {
      this.userId = storedUserId;
    } else {
      this.userId = this.generateId();
      localStorage.setItem('analytics_user_id', this.userId);
    }
    
    // Track initial page load
    this.trackPageView();
    
    // Set up listeners for navigation
    this.setupEventListeners();
    
    // Initialize GPS tracking if enabled
    if (config.enableGps) {
      this.enableGpsTracking();
    }
    
    this.initialized = true;
    console.log("Vignan University Analytics initialized", { 
      userId: this.userId, 
      sessionId: this.sessionId,
      campus: this.campus,
      gpsTracking: this.gpsTracking
    });
  }
  
  private generateId(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }
  
  private setupEventListeners(): void {
    // Listen for route changes in single page app
    const originalPushState = history.pushState;
    history.pushState = (...args) => {
      const result = originalPushState.apply(history, args);
      this.trackPageView();
      return result;
    };
    
    // Listen for back/forward navigation
    window.addEventListener('popstate', () => {
      this.trackPageView();
    });
  }
  
  trackPageView(additionalData: EventData = {}): void {
    const path = window.location.pathname;
    const referrer = document.referrer;
    
    const eventData: PageViewData = {
      path,
      referrer,
      title: document.title,
      ...additionalData
    };

    // Add location data if available
    if (this.lastKnownLocation) {
      eventData.location = this.lastKnownLocation;
    }
    
    this.trackEvent('page_view', eventData);
  }
  
  trackEvent(eventName: string, data: EventData = {}): void {
    const eventData: EventBaseData = {
      ...data,
      userId: this.userId || '',
      sessionId: this.sessionId,
      userRole: localStorage.getItem('userRole') || 'visitor',
      campus: this.campus,
      timestamp: new Date().toISOString(),
    };

    // Add location data if available and not already included
    if (this.lastKnownLocation && !data.location) {
      eventData.location = this.lastKnownLocation;
    }

    const event = {
      name: eventName,
      data: eventData,
      timestamp: Date.now()
    };
    
    this.events.push(event);
    
    // In a real implementation, we would batch send these to a server
    // For now, we'll just log them to console
    console.log('Vignan University Analytics event:', event);
    
    // Store last 50 events in localStorage for demo purposes
    this.storeEvents();
  }
  
  private storeEvents(): void {
    // Keep only the last 50 events to prevent localStorage from getting too large
    const eventsToStore = this.events.slice(-50);
    localStorage.setItem('vignan_analytics_events', JSON.stringify(eventsToStore));
  }
  
  enableGpsTracking(): boolean {
    if (!navigator.geolocation) {
      console.warn('Geolocation is not supported by this browser.');
      return false;
    }
    
    if (this.gpsTracking) return true; // Already enabled
    
    try {
      // Get initial position
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.updateLocation(position);
          this.trackEvent('gps_tracking_enabled', {
            location: this.lastKnownLocation
          });
        },
        (error) => {
          console.warn('Error getting location:', error.message);
          this.trackEvent('gps_tracking_error', { error: error.message });
        }
      );
      
      // Set up continuous watching if supported
      this.watchId = navigator.geolocation.watchPosition(
        (position) => {
          this.updateLocation(position);
        },
        (error) => {
          console.warn('Error watching location:', error.message);
          this.trackEvent('gps_tracking_error', { error: error.message });
        },
        {
          enableHighAccuracy: true,
          maximumAge: 30000, // 30 seconds
          timeout: 27000 // 27 seconds
        }
      );
      
      this.gpsTracking = true;
      return true;
    } catch (error) {
      console.error('Failed to enable GPS tracking:', error);
      return false;
    }
  }
  
  disableGpsTracking(): void {
    if (this.watchId !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
      this.gpsTracking = false;
      this.trackEvent('gps_tracking_disabled', {});
    }
  }
  
  private updateLocation(position: GeolocationPosition): void {
    this.lastKnownLocation = {
      lat: position.coords.latitude,
      lng: position.coords.longitude
    };
    
    // Track significant location changes (over 100 meters)
    if (this.shouldTrackLocationChange()) {
      this.trackEvent('location_updated', {
        location: this.lastKnownLocation,
        accuracy: position.coords.accuracy,
        speed: position.coords.speed,
        heading: position.coords.heading
      });
    }
  }
  
  private shouldTrackLocationChange(): boolean {
    // In a real implementation, we would check if the location has changed significantly
    // For simplicity, we'll track every 5th update
    return this.events.filter(e => e.name === 'location_updated').length % 5 === 0;
  }
  
  isGpsTrackingEnabled(): boolean {
    return this.gpsTracking;
  }
  
  getLastKnownLocation(): LocationData | null {
    return this.lastKnownLocation;
  }
  
  // Get stored events (for demo/debugging)
  getEvents(): Array<{name: string, data: EventData, timestamp: number}> {
    return this.events;
  }
  
  // Get campus-specific metrics
  getCampusMetrics(): Record<string, any> {
    const pageViews: Record<string, number> = {};
    const userTypes: Record<string, number> = {};
    let totalEvents = 0;
    
    this.events.forEach(event => {
      totalEvents++;
      
      if (event.name === 'page_view' && event.data.path) {
        pageViews[event.data.path] = (pageViews[event.data.path] || 0) + 1;
      }
      
      if (event.data.userRole) {
        userTypes[event.data.userRole] = (userTypes[event.data.userRole] || 0) + 1;
      }
    });
    
    return {
      campus: this.campus,
      totalEvents,
      pageViews,
      userTypes,
      locationTrackingEnabled: this.gpsTracking,
      lastKnownLocation: this.lastKnownLocation
    };
  }
}

// Export singleton instance
const analyticsService = new AnalyticsService();
export default analyticsService;
