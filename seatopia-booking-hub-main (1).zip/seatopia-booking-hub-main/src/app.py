
from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "vignan_transport_secret_key"

# Database setup
def get_db_connection():
    conn = sqlite3.connect('transport.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute('''
    CREATE TABLE IF NOT EXISTS routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        departure TEXT NOT NULL,
        arrival TEXT NOT NULL,
        departure_time TEXT NOT NULL,
        arrival_time TEXT NOT NULL,
        price REAL NOT NULL,
        total_seats INTEGER NOT NULL,
        bus_type TEXT NOT NULL
    )
    ''')
    
    conn.execute('''
    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        route_id INTEGER,
        customer_name TEXT NOT NULL,
        customer_email TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        seat_number INTEGER NOT NULL,
        booking_date TEXT NOT NULL,
        journey_date TEXT NOT NULL,
        FOREIGN KEY (route_id) REFERENCES routes (id)
    )
    ''')
    
    # Insert sample routes if none exist
    if conn.execute('SELECT COUNT(*) FROM routes').fetchone()[0] == 0:
        sample_routes = [
            ('Morning Express', 'Main Campus', 'Guntur', '07:30', '08:15', 25.00, 40, 'AC'),
            ('Afternoon Shuttle', 'Main Campus', 'Vijayawada', '13:00', '14:30', 45.50, 30, 'AC'),
            ('Evening Campus Bus', 'Guntur', 'Main Campus', '17:30', '18:15', 25.00, 36, 'Non-AC'),
            ('Night Service', 'Vijayawada', 'Main Campus', '20:00', '21:30', 45.00, 40, 'AC'),
            ('Morning College Bus', 'Tenali', 'Main Campus', '07:00', '08:00', 30.00, 40, 'Non-AC'),
            ('Evening Return Bus', 'Main Campus', 'Tenali', '17:00', '18:00', 30.00, 40, 'Non-AC'),
            ('Weekend Special', 'Main Campus', 'Bapatla', '09:00', '10:30', 35.00, 30, 'AC')
        ]
        conn.executemany('''
        INSERT INTO routes (name, departure, arrival, departure_time, arrival_time, price, total_seats, bus_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', sample_routes)
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Routes
@app.route('/')
def index():
    conn = get_db_connection()
    routes = conn.execute('SELECT * FROM routes LIMIT 6').fetchall()
    conn.close()
    today = datetime.now().strftime('%Y-%m-%d')
    return render_template('index.html', routes=routes, today=today)

@app.route('/search')
def search_routes():
    from_location = request.args.get('from', '')
    to_location = request.args.get('to', '')
    journey_date = request.args.get('date', '')
    
    if not from_location or not to_location or not journey_date:
        flash('Please select both departure and destination locations and journey date.', 'error')
        return redirect(url_for('index'))
    
    conn = get_db_connection()
    routes = conn.execute(
        'SELECT * FROM routes WHERE departure = ? AND arrival = ?',
        (from_location, to_location)
    ).fetchall()
    conn.close()
    
    return render_template(
        'search_results.html', 
        routes=routes, 
        from_location=from_location, 
        to_location=to_location, 
        journey_date=journey_date
    )

@app.route('/seats/<int:route_id>')
def seats(route_id):
    journey_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    
    conn = get_db_connection()
    route = conn.execute('SELECT * FROM routes WHERE id = ?', (route_id,)).fetchone()
    
    # Get booked seats for this route on this date
    booked_seats = conn.execute(
        'SELECT seat_number FROM bookings WHERE route_id = ? AND journey_date = ?', 
        (route_id, journey_date)
    ).fetchall()
    
    booked_seat_numbers = [seat['seat_number'] for seat in booked_seats]
    conn.close()
    
    if route is None:
        flash('Route not found!', 'error')
        return redirect(url_for('index'))
    
    return render_template('seats.html', route=route, booked_seats=booked_seat_numbers, journey_date=journey_date)

@app.route('/booking/<int:route_id>', methods=['GET', 'POST'])
def booking(route_id):
    journey_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        customer_email = request.form['customer_email']
        customer_phone = request.form['customer_phone']
        seat_number = request.form['seat_number']
        journey_date = request.form['journey_date']
        
        if not customer_name or not customer_email or not customer_phone or not seat_number:
            flash('All fields are required!', 'error')
            return redirect(url_for('booking', route_id=route_id, date=journey_date))
        
        conn = get_db_connection()
        
        # Check if seat is already booked for this journey date
        existing_booking = conn.execute(
            'SELECT * FROM bookings WHERE route_id = ? AND seat_number = ? AND journey_date = ?',
            (route_id, seat_number, journey_date)
        ).fetchone()
        
        if existing_booking:
            conn.close()
            flash('This seat is already booked for this date!', 'error')
            return redirect(url_for('seats', route_id=route_id, date=journey_date))
        
        # Save booking
        conn.execute(
            'INSERT INTO bookings (route_id, customer_name, customer_email, customer_phone, seat_number, booking_date, journey_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (route_id, customer_name, customer_email, customer_phone, seat_number, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), journey_date)
        )
        conn.commit()
        
        # Get route details for confirmation
        route = conn.execute('SELECT * FROM routes WHERE id = ?', (route_id,)).fetchone()
        conn.close()
        
        # Set session for confirmation
        session['booking'] = {
            'customer_name': customer_name,
            'customer_email': customer_email,
            'customer_phone': customer_phone,
            'seat_number': seat_number,
            'journey_date': journey_date,
            'route': dict(route)
        }
        
        return redirect(url_for('confirmation'))
    
    conn = get_db_connection()
    route = conn.execute('SELECT * FROM routes WHERE id = ?', (route_id,)).fetchone()
    conn.close()
    
    seat_number = request.args.get('seat', '')
    
    return render_template('booking.html', route=route, seat_number=seat_number, journey_date=journey_date)

@app.route('/confirmation')
def confirmation():
    if 'booking' not in session:
        return redirect(url_for('index'))
    
    booking_data = session['booking']
    # Clear session after showing confirmation
    session.pop('booking', None)
    
    # Generate a unique booking ID
    booking_id = f"VT{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    return render_template('confirmation.html', booking=booking_data, booking_id=booking_id)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/schedules')
def schedules():
    conn = get_db_connection()
    routes = conn.execute('SELECT * FROM routes ORDER BY departure, departure_time').fetchall()
    conn.close()
    return render_template('schedules.html', routes=routes)

if __name__ == '__main__':
    app.run(debug=True)
