
import { useEffect } from 'react';
import analyticsService from '../services/analyticsService';

export const useAnalytics = () => {
  useEffect(() => {
    // Initialize analytics service with campus information
    analyticsService.initialize({
      campus: 'Vignan University Vadlamudi'
    });
  }, []);

  return {
    trackEvent: (eventName: string, data: Record<string, any> = {}) => {
      // Add campus information to all tracked events
      analyticsService.trackEvent(eventName, {
        ...data,
        campus: 'Vignan University Vadlamudi'
      });
    },
    trackPageView: (additionalData: Record<string, any> = {}) => {
      // Track page view with campus information
      analyticsService.trackPageView({
        ...additionalData,
        campus: 'Vignan University Vadlamudi'
      });
    },
    enableGpsTracking: () => {
      return analyticsService.enableGpsTracking();
    },
    disableGpsTracking: () => {
      analyticsService.disableGpsTracking();
    },
    isGpsTrackingEnabled: () => {
      return analyticsService.isGpsTrackingEnabled();
    },
    getLastKnownLocation: () => {
      return analyticsService.getLastKnownLocation();
    }
  };
};
