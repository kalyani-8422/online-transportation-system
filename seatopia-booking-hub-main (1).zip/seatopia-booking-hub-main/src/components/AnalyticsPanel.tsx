
import React, { useState, useEffect } from 'react';
import analyticsService from '../services/analyticsService';
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const AnalyticsPanel = () => {
  const [events, setEvents] = useState<Array<{name: string, data: Record<string, any>, timestamp: number}>>([]);
  const [pageViews, setPageViews] = useState<Record<string, number>>({});
  const [userRoleCounts, setUserRoleCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    // Get events from analytics service
    const storedEvents = analyticsService.getEvents();
    setEvents(storedEvents);

    // Calculate page views by path
    const views: Record<string, number> = {};
    const roleCounts: Record<string, number> = {};
    
    storedEvents.forEach(event => {
      if (event.name === 'page_view' && event.data.path) {
        views[event.data.path] = (views[event.data.path] || 0) + 1;
      }
      
      if (event.data.userRole) {
        roleCounts[event.data.userRole] = (roleCounts[event.data.userRole] || 0) + 1;
      }
    });
    
    setPageViews(views);
    setUserRoleCounts(roleCounts);
    
    // Setup interval to refresh data
    const interval = setInterval(() => {
      const updatedEvents = analyticsService.getEvents();
      setEvents(updatedEvents);
      
      // Recalculate metrics
      const updatedViews: Record<string, number> = {};
      const updatedRoleCounts: Record<string, number> = {};
      
      updatedEvents.forEach(event => {
        if (event.name === 'page_view' && event.data.path) {
          updatedViews[event.data.path] = (updatedViews[event.data.path] || 0) + 1;
        }
        
        if (event.data.userRole) {
          updatedRoleCounts[event.data.userRole] = (updatedRoleCounts[event.data.userRole] || 0) + 1;
        }
      });
      
      setPageViews(updatedViews);
      setUserRoleCounts(updatedRoleCounts);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Analytics Dashboard</CardTitle>
          <CardDescription>Track user activity and page views</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Page Views</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Page</TableHead>
                      <TableHead className="text-right">Views</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(pageViews).map(([path, count]) => (
                      <TableRow key={path}>
                        <TableCell>{path || '/'}</TableCell>
                        <TableCell className="text-right">{count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>User Groups</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role</TableHead>
                      <TableHead className="text-right">Events</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(userRoleCounts).map(([role, count]) => (
                      <TableRow key={role}>
                        <TableCell className="capitalize">{role}</TableCell>
                        <TableCell className="text-right">{count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Recent Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-64 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Event</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Page</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events.slice().reverse().slice(0, 20).map((event, idx) => (
                      <TableRow key={idx}>
                        <TableCell>{event.name}</TableCell>
                        <TableCell>{event.data.userRole || 'unknown'}</TableCell>
                        <TableCell>{event.data.path || '-'}</TableCell>
                        <TableCell>{new Date(event.timestamp).toLocaleTimeString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
};

export default AnalyticsPanel;
