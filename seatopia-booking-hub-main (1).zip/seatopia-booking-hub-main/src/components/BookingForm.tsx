
import { useState } from "react";
import { useNavigate } from "react-router-dom";

interface BookingFormProps {
  routeId: number;
  seatNumber: number;
  routeName: string;
  departureLocation: string;
  arrivalLocation: string;
  departureTime: string;
  arrivalTime: string;
  price: number;
}

const BookingForm = ({
  routeId,
  seatNumber,
  routeName,
  departureLocation,
  arrivalLocation,
  departureTime,
  arrivalTime,
  price,
}: BookingFormProps) => {
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!customerName || !customerEmail || !seatNumber) {
      return;
    }
    
    // In a real app, this would make an API call to save the booking
    // For now, we'll just navigate to a confirmation screen with the data
    navigate(`/confirmation`, {
      state: {
        booking: {
          customerName,
          customerEmail,
          seatNumber,
          routeId,
          routeName,
          departureLocation,
          arrivalLocation,
          departureTime,
          arrivalTime,
          price,
          bookingId: Math.floor(100000 + Math.random() * 900000).toString(),
          date: new Date().toISOString().split("T")[0]
        }
      }
    });
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="p-6">
        <h2 className="text-lg font-semibold text-gray-800">Booking Summary</h2>
        <div className="mt-4 space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Route:</span>
            <span className="font-medium">{routeName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Departure:</span>
            <span className="font-medium">{departureLocation} at {departureTime}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Arrival:</span>
            <span className="font-medium">{arrivalLocation} at {arrivalTime}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Seat Number:</span>
            <span className="font-medium">{seatNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Price:</span>
            <span className="font-medium text-indigo-600">₹{price.toFixed(2)}</span>
          </div>
        </div>
      </div>
      <div className="p-6 bg-gray-50 border-t border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Passenger Information</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="customer_name" className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              id="customer_name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          <div>
            <label htmlFor="customer_email" className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              id="customer_email"
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Confirm Booking
          </button>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;
