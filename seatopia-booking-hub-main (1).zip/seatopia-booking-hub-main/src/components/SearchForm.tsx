
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const SearchForm = () => {
  const [fromLocation, setFromLocation] = useState("");
  const [toLocation, setToLocation] = useState("");
  const [journeyDate, setJourneyDate] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!fromLocation || !toLocation || !journeyDate) {
      return;
    }
    
    // Navigate to search results with query params
    navigate(`/search?from=${fromLocation}&to=${toLocation}&date=${journeyDate}`);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Find Your Route</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="from" className="block text-sm font-medium text-gray-700 mb-1">
            From
          </label>
          <select
            id="from"
            value={fromLocation}
            onChange={(e) => setFromLocation(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            required
          >
            <option value="">Select departure point</option>
            <option value="Main Campus">Main Campus (Vadlamudi)</option>
            <option value="Guntur">Guntur City</option>
            <option value="Vijayawada">Vijayawada</option>
            <option value="Tenali">Tenali</option>
            <option value="Bapatla">Bapatla</option>
          </select>
        </div>
        <div>
          <label htmlFor="to" className="block text-sm font-medium text-gray-700 mb-1">
            To
          </label>
          <select
            id="to"
            value={toLocation}
            onChange={(e) => setToLocation(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            required
          >
            <option value="">Select destination</option>
            <option value="Main Campus">Main Campus (Vadlamudi)</option>
            <option value="Guntur">Guntur City</option>
            <option value="Vijayawada">Vijayawada</option>
            <option value="Tenali">Tenali</option>
            <option value="Bapatla">Bapatla</option>
          </select>
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
            Date of Journey
          </label>
          <input
            type="date"
            id="date"
            value={journeyDate}
            onChange={(e) => setJourneyDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            required
            min={new Date().toISOString().split("T")[0]}
          />
        </div>
        <button
          type="submit"
          className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          Search Buses
        </button>
      </form>
    </div>
  );
};

export default SearchForm;
