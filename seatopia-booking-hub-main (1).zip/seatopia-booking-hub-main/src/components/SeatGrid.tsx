
import { useState } from "react";

interface Seat {
  id: number;
  number: number;
  isAvailable: boolean;
}

interface SeatGridProps {
  totalSeats: number;
  bookedSeats: number[];
  onSeatSelect: (seatNumber: number) => void;
}

const SeatGrid = ({ totalSeats, bookedSeats, onSeatSelect }: SeatGridProps) => {
  const [selectedSeat, setSelectedSeat] = useState<number | null>(null);

  // Generate seats array
  const generateSeats = (): Seat[] => {
    const seats: Seat[] = [];
    for (let i = 1; i <= totalSeats; i++) {
      seats.push({
        id: i,
        number: i,
        isAvailable: !bookedSeats.includes(i),
      });
    }
    return seats;
  };

  const seats = generateSeats();

  const handleSeatClick = (seat: Seat) => {
    if (!seat.isAvailable) return;
    
    const newSelectedSeat = selectedSeat === seat.number ? null : seat.number;
    setSelectedSeat(newSelectedSeat);
    onSeatSelect(newSelectedSeat || 0);
  };

  // Calculate the number of rows (4 seats per row)
  const rows = Math.ceil(totalSeats / 4);

  return (
    <div className="seat-selection-container">
      <div className="mb-6 bg-white p-4 rounded-lg shadow-md">
        <div className="flex justify-center items-center mb-4 space-x-4">
          <div className="flex items-center">
            <div className="w-6 h-6 rounded-sm bg-gray-200 border border-gray-300 mr-2"></div>
            <span className="text-sm">Available</span>
          </div>
          <div className="flex items-center">
            <div className="w-6 h-6 rounded-sm bg-indigo-500 border border-indigo-600 mr-2"></div>
            <span className="text-sm">Selected</span>
          </div>
          <div className="flex items-center">
            <div className="w-6 h-6 rounded-sm bg-gray-400 border border-gray-500 mr-2"></div>
            <span className="text-sm">Booked</span>
          </div>
        </div>
      </div>

      <div className="bus-layout bg-white p-6 rounded-lg shadow-md">
        <div className="driver-area bg-gray-200 p-4 rounded-t-lg flex items-center justify-center mb-4">
          <div className="steering-wheel w-8 h-8 rounded-full border-4 border-gray-500 flex items-center justify-center">
            <div className="w-4 h-0.5 bg-gray-500 absolute"></div>
            <div className="w-0.5 h-4 bg-gray-500 absolute"></div>
          </div>
          <span className="ml-3 font-medium">Driver</span>
        </div>
        
        <div className="seats-grid">
          {Array.from({ length: rows }).map((_, rowIndex) => (
            <div key={rowIndex} className="flex mb-4 justify-center" data-row={rowIndex + 1}>
              {seats.slice(rowIndex * 4, rowIndex * 4 + 2).map((seat) => (
                <div
                  key={seat.id}
                  className={`
                    w-12 h-12 mx-1 flex items-center justify-center rounded-md cursor-pointer transition-all duration-200
                    ${
                      !seat.isAvailable
                        ? "bg-gray-400 cursor-not-allowed"
                        : selectedSeat === seat.number
                        ? "bg-indigo-500 text-white shadow-md"
                        : "bg-gray-200 hover:bg-gray-300"
                    }
                  `}
                  onClick={() => handleSeatClick(seat)}
                >
                  {seat.number}
                </div>
              ))}
              
              <div className="w-8 mx-2"></div> {/* Aisle */}
              
              {seats.slice(rowIndex * 4 + 2, rowIndex * 4 + 4).map((seat) => (
                <div
                  key={seat.id}
                  className={`
                    w-12 h-12 mx-1 flex items-center justify-center rounded-md cursor-pointer transition-all duration-200
                    ${
                      !seat.isAvailable
                        ? "bg-gray-400 cursor-not-allowed"
                        : selectedSeat === seat.number
                        ? "bg-indigo-500 text-white shadow-md"
                        : "bg-gray-200 hover:bg-gray-300"
                    }
                  `}
                  onClick={() => handleSeatClick(seat)}
                >
                  {seat.number}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SeatGrid;
