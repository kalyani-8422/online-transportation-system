
import { Link } from "react-router-dom";

interface RouteCardProps {
  id: number;
  name: string;
  departure: string;
  arrival: string;
  departureTime: string;
  arrivalTime: string;
  price: number;
}

const RouteCard = ({
  id,
  name,
  departure,
  arrival,
  departureTime,
  arrivalTime,
  price,
}: RouteCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-800">{name}</h2>
        <div className="mt-4 space-y-4">
          <div className="flex items-center">
            <div className="flex-1">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-indigo-600"></div>
                <div className="ml-2 flex flex-col">
                  <span className="text-sm text-gray-500">From:</span>
                  <span className="font-medium">{departure}</span>
                </div>
              </div>
              <div className="w-0.5 h-6 bg-gray-300 ml-1.5 my-1"></div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-indigo-600"></div>
                <div className="ml-2 flex flex-col">
                  <span className="text-sm text-gray-500">To:</span>
                  <span className="font-medium">{arrival}</span>
                </div>
              </div>
            </div>
            <div className="flex-1">
              <div className="space-y-2">
                <div>
                  <span className="text-sm text-gray-500">Departs:</span>
                  <span className="ml-2 font-medium">{departureTime}</span>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Arrives:</span>
                  <span className="ml-2 font-medium">{arrivalTime}</span>
                </div>
              </div>
            </div>
            <div className="flex-none">
              <div className="text-xl font-bold text-indigo-600">₹{price.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
        <Link 
          to={`/seats/${id}`}
          className="w-full block text-center py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-md transition-colors"
        >
          Book Now
        </Link>
      </div>
    </div>
  );
};

export default RouteCard;
