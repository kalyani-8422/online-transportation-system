
import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { UserRound, Menu, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

type UserRole = 'student' | 'faculty' | 'admin' | null;

// Sample user credentials
const USERS = {
  student: { username: 'student', password: 'student123', role: 'student' },
  faculty: { username: 'faculty', password: 'faculty123', role: 'faculty' },
  admin: { username: 'admin', password: 'admin123', role: 'admin' }
};

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [showLoginDropdown, setShowLoginDropdown] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  // Check if user is already logged in on component mount
  useEffect(() => {
    const storedIsLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const storedUserRole = localStorage.getItem('userRole') as UserRole;
    
    if (storedIsLoggedIn && storedUserRole) {
      setIsLoggedIn(true);
      setUserRole(storedUserRole);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    // Check credentials against our sample users
    const user = Object.values(USERS).find(u => u.username === username);
    
    if (!user) {
      setLoginError('Username not found');
      return;
    }
    
    if (user.password !== password) {
      setLoginError('Incorrect password');
      return;
    }
    
    // Login successful
    setIsLoggedIn(true);
    setUserRole(user.role as UserRole);
    setShowLoginModal(false);
    setUsername('');
    setPassword('');
    
    // Store login state in localStorage
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('userRole', user.role);
    
    toast({
      title: "Logged In Successfully",
      description: `Welcome back, ${username}!`,
    });
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserRole(null);
    setShowLoginDropdown(false);
    
    // Clear login state from localStorage
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully",
    });
    
    // Navigate to home
    navigate('/');
  };

  return (
    <>
      <nav className="bg-indigo-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="text-xl font-bold text-white">
                Vignan Transport
              </Link>
            </div>
            
            {/* Desktop menu */}
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <div className="flex space-x-4">
                <Link to="/" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                  Home
                </Link>
                <Link to="/about" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                  About Us
                </Link>
                <Link to="/contact" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                  Contact
                </Link>
                <Link to="/schedules" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                  Schedules
                </Link>
                
                {/* Show different links based on user role */}
                {isLoggedIn && userRole === 'admin' && (
                  <Link to="/admin/dashboard" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                    Admin Dashboard
                  </Link>
                )}
                {isLoggedIn && (userRole === 'faculty' || userRole === 'admin') && (
                  <Link to="/faculty/bookings" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                    Manage Bookings
                  </Link>
                )}
                {isLoggedIn && (
                  <Link to="/my-bookings" className="px-3 py-2 text-sm font-medium text-white hover:text-indigo-200">
                    My Bookings
                  </Link>
                )}
              </div>
              
              {/* Login/Profile button */}
              <div className="ml-4 relative">
                {!isLoggedIn ? (
                  <div className="relative">
                    <button
                      onClick={() => setShowLoginModal(true)}
                      className="flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-700 rounded-md hover:bg-indigo-600"
                    >
                      <UserRound className="w-4 h-4 mr-1" />
                      Login
                    </button>
                  </div>
                ) : (
                  <div className="relative">
                    <button
                      onClick={() => setShowLoginDropdown(!showLoginDropdown)}
                      className="flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-700 rounded-md hover:bg-indigo-600"
                    >
                      <UserRound className="w-4 h-4 mr-1" />
                      {userRole?.charAt(0).toUpperCase() + userRole?.slice(1)}
                    </button>
                    
                    {showLoginDropdown && (
                      <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
                        <div className="block px-4 py-2 text-sm text-gray-700 border-b">
                          Logged in as <strong>{userRole}</strong>
                        </div>
                        <button
                          onClick={handleLogout}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          Logout
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center sm:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-indigo-200 hover:text-white hover:bg-indigo-700 focus:outline-none"
              >
                {mobileMenuOpen ? (
                  <X className="block h-6 w-6" aria-hidden="true" />
                ) : (
                  <Menu className="block h-6 w-6" aria-hidden="true" />
                )}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link to="/" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                Home
              </Link>
              <Link to="/about" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                About Us
              </Link>
              <Link to="/contact" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                Contact
              </Link>
              <Link to="/schedules" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                Schedules
              </Link>
              
              {/* Conditional links based on user role */}
              {isLoggedIn && userRole === 'admin' && (
                <Link to="/admin/dashboard" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                  Admin Dashboard
                </Link>
              )}
              {isLoggedIn && (userRole === 'faculty' || userRole === 'admin') && (
                <Link to="/faculty/bookings" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                  Manage Bookings
                </Link>
              )}
              {isLoggedIn && (
                <Link to="/my-bookings" className="block px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md">
                  My Bookings
                </Link>
              )}
              
              {/* Login options in mobile menu */}
              {!isLoggedIn ? (
                <button
                  onClick={() => setShowLoginModal(true)}
                  className="block w-full text-left px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md"
                >
                  Login
                </button>
              ) : (
                <div className="pt-4 pb-3 border-t border-indigo-700">
                  <div className="px-3 py-2 text-base font-medium text-white">
                    Logged in as <strong>{userRole}</strong>
                  </div>
                  <div className="px-2 space-y-1">
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-3 py-2 text-base font-medium text-white hover:bg-indigo-700 rounded-md"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>
      
      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Login</h2>
              <button 
                onClick={() => setShowLoginModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleLogin}>
              <div className="mb-4">
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              
              {loginError && (
                <div className="mb-4 text-red-500 text-sm">
                  {loginError}
                </div>
              )}
              
              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700"
              >
                Login
              </button>
            </form>
            
            <div className="mt-4">
              <p className="text-sm text-gray-600 mb-2">Quick login as:</p>
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    setUsername(USERS.student.username);
                    setPassword(USERS.student.password);
                  }}
                  className="flex-1 bg-blue-100 text-blue-800 py-1 rounded text-sm"
                >
                  Student
                </button>
                <button
                  onClick={() => {
                    setUsername(USERS.faculty.username);
                    setPassword(USERS.faculty.password);
                  }}
                  className="flex-1 bg-green-100 text-green-800 py-1 rounded text-sm"
                >
                  Faculty
                </button>
                <button
                  onClick={() => {
                    setUsername(USERS.admin.username);
                    setPassword(USERS.admin.password);
                  }}
                  className="flex-1 bg-purple-100 text-purple-800 py-1 rounded text-sm"
                >
                  Admin
                </button>
              </div>
              <div className="mt-4 text-xs text-gray-500">
                <p><strong>Student:</strong> username: student, password: student123</p>
                <p><strong>Faculty:</strong> username: faculty, password: faculty123</p>
                <p><strong>Admin:</strong> username: admin, password: admin123</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;
