
# TransitBooker - Flask Seat Booking System

A clean, user-friendly seat booking system for transportation services built with Flask.

## Features

- Browse available transportation routes
- Interactive seat selection
- Passenger information collection
- Booking confirmation with e-ticket
- Responsive design that works on desktop and mobile

## Tech Stack

- **Backend**: Flask
- **Database**: SQLite
- **Frontend**: HTML, CSS, JavaScript

## Getting Started

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)

### Installation

1. Clone the repository
   ```
   git clone https://github.com/yourusername/transit-booker.git
   cd transit-booker
   ```

2. Create a virtual environment (optional but recommended)
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies
   ```
   pip install -r requirements.txt
   ```

4. Run the application
   ```
   python app.py
   ```

5. Open your browser and navigate to http://127.0.0.1:5000

## Project Structure

- `/src/app.py` - Main Flask application
- `/src/templates/` - HTML templates
- `/src/static/css/` - CSS stylesheets
- `booking.db` - SQLite database (created on first run)

## Database Schema

- **routes**: Stores information about transportation routes
- **bookings**: Stores passenger bookings

## License

This project is licensed under the MIT License - see the LICENSE file for details.
